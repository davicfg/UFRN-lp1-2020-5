#include "App.hpp"
#include "Estabelecimento.hpp"

#include <iostream>
int main(int argc, char const *argv[])
{
  App applicacao;
  applicacao.run();
  return 0;
}
